<div class="container-fluid" id="error_page">
	<div class="row">
		<div class="col-md-2">
		</div>
		<div class="col-md-8">
		<h1>Oops!</h1>
		<h4>We can't seem to find the page you're looking for.</h4>
		
		<div>Connection failed please check your database settings</div>

		</div>
		<div class="col-md-2">
		</div>
	</div>
</div>