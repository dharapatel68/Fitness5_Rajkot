</div></div>
<script src="../js/lightbox.js"></script>
<script src="<?php echo SITE_URL; ?>/js/chosen.jquery.js" type="text/javascript"></script>
<script src="<?php echo SITE_URL; ?>/js/ImageSelect.jquery.js" type="text/javascript"></script>
  <script type="text/javascript">
    $(".my-select").chosen({width:"100%"});
  </script>
</body>
</html>