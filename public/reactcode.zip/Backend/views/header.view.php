<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>GoFit - Dashboard</title>
<link href="../css/custom.css" rel="stylesheet"/>
<link rel="stylesheet" type="text/css" href="../fonts/flaticon.css">
<script src="../js/sweetalert.js"></script>
<script src="../js/jquery-3.1.1.min.js"></script>
<script src="../js/custom.js"></script>
<link rel="shortcut icon" href="../favicon.png" />
<script src="//cdn.ckeditor.com/4.7.1/basic/ckeditor.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>

</head>
<body>

<!--
App Name: GoFit
Description: React Native App Template
Author: Wicombit
Author URI: https://codecanyon.net/user/wicombit/portfolio
Version: 1.00
-->

<div class="animated fadeIn">